#pragma once
#include "Engine.h"		//! Superclass for accessing OpenGL/Context windowing
#include "Texture.h"	//! Handles Texture loading for bitmap images
#include "Camera.h"  //! Camera class
#include <vector>		//! Utility for maintaining DispalyableObjects in system

class DisplayableObject; // Anonymous

class Scene : public Engine
{
public:
	/**
	 * Constructor, overrides Engine() and takes in command line arguments, a title and initial window dimensions.
	 */
	Scene(int argc, char** argv, const char *title, const int& windowWidth, const int& windowHeight);
	virtual ~Scene();

	static int GetWindowWidth();
	static int GetWindowHeight();
	static int GetTexture(std::string fileName);
	static Camera* GetCamera() {
		return &camera;
	}

protected:
	/**
	* This must be overloaded this to add {@link DisplayableObject}s to your
	* scene.
	* @see #Projection()
	*/
	virtual void Initialise() = 0;
	void Draw();
	/**
	* Called when the window is resized, and handles resizing events.
	* <p>
	* You should this function to handle the window being resized. The default property is to update the
	*/
	void Reshape(int w, int h);
	/**
	 * Sets the projection properties of the scene. Override to change projection properties.
	 * <p>
	 * Default: Orthographic mode
	 */
	virtual void Projection();

	/**
	* The update function for {@link Camera} and {@link Animation}. Calculates the time-delay since
	* the last update and passes as a parameter to the respective class's {@code Update()} functions.
	*/
	void Update(const double& deltaTime);

	// Input handling methods
	void HandleKey(unsigned char key, int state, int x, int y);
	void HandleSpecialKey(int key, int state, int x, int y);
	void HandleMouse(int button, int state, int x, int y);
	void HandleMouseDrag(int x, int y);
	void HandleMouseMove(int x, int y);
	void AddObjectToScene(DisplayableObject *obj);

private:
	static Camera camera;
	static Texture texture;
	std::vector<DisplayableObject*> objects;
};

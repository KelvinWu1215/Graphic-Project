#define GLUT_DISABLE_ATEXIT_HACK
#define GL_SILENCE_DEPRECATION
#pragma once
/**
* Class for giving an coursework object input handling. Any class you want to have input handling
* should subclass the {@code public Input}. e.g. {@code MyObject : public DisplayableObject, public Input}
* <p>
* Methods will be called from a {@link Scene} renderer to give input from keyboard and mouse
* @see Camera
* @author wil
*/
class Input
{
public:
	Input(void){}
	virtual ~Input(void){}
	virtual void HandleKey(unsigned char key, int state, int x, int y) {};
	virtual void HandleSpecialKey(int key, int state, int x, int y) {};
	virtual void HandleMouse(int button, int state, int x, int y){};
	virtual void HandleMouseDrag(int x, int y){};
	virtual void HandleMouseMove(int x, int y){};
};

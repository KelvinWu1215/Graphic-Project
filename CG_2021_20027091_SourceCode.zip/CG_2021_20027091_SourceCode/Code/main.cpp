/**
* Entry file to framework. Should not edit this file, though to change window size, adjust parameters in creastion of new scene
* <p>
*/
#include "MyScene.h"
int main(int argc, char* argv[])
{
	// Create new instance of MyScene - the OpenGL context on which your coursework is built
	MyScene *scene = NULL;
	scene = new MyScene(argc, argv, "MyScene", static_cast<const int>(800), static_cast<const int>(600));

	// Begin the main GL loop
	scene->Run();

	// On exit, clean up and return success (0x0)
	delete scene;
	return 0;
}

#pragma once

#pragma once
#include "DisplayableObject.h"

class Fridge :
	public DisplayableObject
{
public:
	Fridge() {};
	Fridge(const std::string& filename1, const std::string& filename2, const std::string& filename3);
	~Fridge() {};

	void Display();
	void DrawFridge();
	void DrawFrame();
	void DrawDoor();
	void DrawHandle();
private:
	GLint texID;
	GLint texID2;
	GLint texID3;
};


#include "AddBook.h"

// bound the texture on the object
AddBook::AddBook(const std::string& filename1, const std::string& filename2) {
	texID = Scene::GetTexture(filename1);
	texID2 = Scene::GetTexture(filename2);
}

void AddBook::Display() {
	DrawBook();
	DrawBook2();
}

//Draw the book
void AddBook::DrawBook() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);

	//set the lighting reflection
	float lighting1[] = { 0.99f,0.99f,0.99f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	//enable the texture which is bound with texture ID
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
    glTranslatef(scale[0] * (1.8f),0, 0);
	glBegin(GL_QUADS);
	//set the actual lighting attributes
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));

	//draw the polygons
	//front
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-0.63f), scale[0] * (1.56f), scale[0] * (-1.65f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-0.70f), scale[0] * (1.56f), scale[0] * (-1.65f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-0.70f), scale[0] * (1.125f), scale[0] * (-1.65f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-0.63f), scale[0] * (1.125f), scale[0] * (-1.65f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

//in this function, the step is same as the DrawBook()
void AddBook::DrawBook2() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	float lighting1[] = { 0.85f,0.85f,0.85f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
    glTranslatef(scale[0] * (1.8f),0, 0);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));

	//right
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-0.63f), scale[0] * (1.1f), scale[0] * (-1.88f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-0.63f), scale[0] * (1.56f), scale[0] * (-1.88f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-0.63f), scale[0] * (1.56f), scale[0] * (-1.65f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-0.63f), scale[0] * (1.1f), scale[0] * (-1.65f));
	//left
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-0.70f), scale[0] * (1.1f), scale[0] * (-1.88f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-0.70f), scale[0] * (1.56f), scale[0] * (-1.88f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-0.70f), scale[0] * (1.56f), scale[0] * (-1.65f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-0.70f), scale[0] * (1.1f), scale[0] * (-1.65f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

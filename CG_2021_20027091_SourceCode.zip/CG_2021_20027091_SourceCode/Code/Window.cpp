#include "Window.h"

/*
* In this class, a object (window) is set the transparency to show the texture which is outside the room
*/


//get the texture to set the window
Window::Window(const std::string& filename1) :Window() {
	texID = Scene::GetTexture(filename1);

}

void Window::Display()
{
	Draw();
}
void Window::Draw() {

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);

	//in lighting1, set the transparency of the window using the alpha value.
	float lighting1[] = { 0.99f,0.99f,0.99f,.48f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

	// draw the left wall
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	//bind the texture and set the normals of this face
	glNormal3f(1.f, 0.f, 0.f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (0.5f), scale[0] * (0.5f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (0.5f), scale[0] * (-0.5f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (1.5f), scale[0] * (-0.5f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (1.5f), scale[0] * (0.5f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
}


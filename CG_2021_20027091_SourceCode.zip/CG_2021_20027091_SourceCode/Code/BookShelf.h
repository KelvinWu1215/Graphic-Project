
#pragma once
#include "DisplayableObject.h"

class BookShelf :
	public DisplayableObject
{
public:
	BookShelf() {};
	BookShelf(const std::string& filename1);
	BookShelf(const std::string& filename1, const std::string& filename2);
	~BookShelf() {};

	void Display();
	void DrawBookShelf();
	void DrawBack();
	void DrawBook();
	void DrawBook2();
private:
	GLint texID;
	GLint texID2;
};


#pragma once
#include "DisplayableObject.h"
#include "Animation.h"

class Balloon :
	public DisplayableObject,
	public Animation
{
public:
	Balloon() {};

    Balloon (const std::string& filename1);
	~Balloon() {};

	void Display();
	void DrawBalloon();
	void DrawBall();
	//get the deltaTime to compute the animation
	void Update(const double& deltaTime);

private:
	GLint texID;
	float yrot = 0;
	float moveX = 0;
	float moveY = 0;
    float moveZ = 0;
	int state = 1;
};


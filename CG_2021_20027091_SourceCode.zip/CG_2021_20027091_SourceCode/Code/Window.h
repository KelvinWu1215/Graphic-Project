#include "DisplayableObject.h"

class Window :
    public DisplayableObject
{
public:
    Window() {};
    Window(const std::string& filename1);
    ~Window() {};

    void Display();
    //void DrawWindow();
    //void DrawFrame();
    void Draw();
private:
    GLint texID;
};

#include "Fan.h"

//display the object fan.
void Fan::Display() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	Material_Fan();
	DrawBase();
	glRotatef(yrot, 0, 1, 0);
	DrawBlades();
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

void Fan::Material_Fan() 
{
	float lighting1[] = { 0.75f,0.75f,0.75f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
}

void Fan::DrawBlades() 
{
	//draw the blades using transformation models
		//first
	glPushMatrix();
	glTranslatef(scale[0] * (0.4f), scale[0] * (2.2f), scale[0] * (0.0f));

	glScalef(7.f, 0.5f, 1.4f);
	glutSolidCube(scale[0] * 0.1);
	glPopMatrix();
	//second
	glPushMatrix();
	glRotatef(72, 0, 1, 0);
	//glRotatef(yrot, 0, 1, 0);
	glTranslatef(scale[0] * (0.4f), scale[0] * (2.2f), scale[0] * (0.0f));
	glScalef(7.f, 0.5f, 1.4f);
	glutSolidCube(scale[0] * 0.1);
	glPopMatrix();
	//third
	glPushMatrix();
	glRotatef(144, 0, 1, 0);
	glTranslatef(scale[0] * (0.4f), scale[0] * (2.2f), scale[0] * (0.0f));
	glScalef(7.f, 0.5f, 1.4f);
	glutSolidCube(scale[0] * 0.1);
	glPopMatrix();
	//fourth
	glPushMatrix();
	glRotatef(216, 0, 1, 0);
	glTranslatef(scale[0] * (0.4f), scale[0] * (2.2f), scale[0] * (0.0f));
	glScalef(7.f, 0.5f, 1.4f);
	glutSolidCube(scale[0] * 0.1);
	glPopMatrix();
    //fifth
    glPushMatrix();
    glRotatef(288, 0, 1, 0);
    glTranslatef(scale[0] * (0.4f), scale[0] * (2.2f), scale[0] * (0.0f));
    glScalef(7.f, 0.5f, 1.4f);
    glutSolidCube(scale[0] * 0.1);
    glPopMatrix();
}

//draw the base of fan
//using the trasformation model
void Fan::DrawBase() {
	GLUquadricObj* obj = gluNewQuadric();
	glPushMatrix();
	glTranslatef(scale[0] * (0.f), scale[0] * (3.f), scale[0] * (0.0f));
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, scale[0] * (0.05), scale[0] * (0.05), scale[0] * (0.8), 100, 100);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(scale[0] * (0.f), scale[0] * (2.2f), scale[0] * (0.0f));
	glutSolidSphere(scale[0] * 0.05, 100, 100);
	glPopMatrix();
}

/*set the speed of rotation of fan.
* 
*	when the scene is created, the fan rotates at an acceleration, and when the speed is constant, it rotates at a constant speed
*	Accelerated motion is composed of multiple increasing uniform motion divisions
*/
void Fan::Update(const double& deltaTime)
{
	count += 100.0f * static_cast<float>(deltaTime);

    yrot += 200.0f * static_cast<float>(deltaTime);

}


#pragma once
#include "DisplayableObject.h"

class Board :
	public DisplayableObject
{
public:
	Board() {};
	Board(const std::string& filename1);
	~Board() {};

	void Display();
	void DrawBoard();
private:
	GLint texID;
};


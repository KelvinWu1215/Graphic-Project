#include "pool.h"

//get the texture in this constructor
Pool::Pool(const std::string& filename1, const std::string& filename2) :Pool() {
	texID = Scene::GetTexture(filename1);
    texID2 = Scene::GetTexture(filename2);


}

void Pool::Display() {

	DrawPool();
}

void Pool::DrawPool() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	float lighting1[] = { 0.9f,0.9f,0.9f,1.0f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

	//draw the Picture Frame which is located on the right wall
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(1.f, 0.f, 0.f);

	//left 
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (0.44f), scale[0] * (-0.99f), scale[0] * (1.5f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (0.44f), scale[0] * (-0.99f), scale[0] * (2.0f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (0.5f), scale[0] * (-0.99f), scale[0] * (2.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (0.5f), scale[0] * (-0.99f), scale[0] * (1.5f));


	//right
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.5f), scale[0] * (-0.99f), scale[0] * (1.5f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.5f), scale[0] * (-0.99f), scale[0] * (2.0f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.55f), scale[0] * (-0.99f), scale[0] * (2.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.55f), scale[0] * (-0.99f), scale[0] * (1.5f));
	//back
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (0.44f), scale[0] * (-0.99f), scale[0] * (1.45f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (0.44f), scale[0] * (-0.99f), scale[0] * (1.5f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.55f), scale[0] * (-0.99f), scale[0] * (1.5f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.55f), scale[0] * (-0.99f), scale[0] * (1.45f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);
    
    //top
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (0.5f), scale[0] * (-0.99f), scale[0] * (1.5f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (0.5f), scale[0] * (-0.99f), scale[0] * (2.0f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.5f), scale[0] * (-0.99f), scale[0] * (2.0f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.5f), scale[0] * (-0.99f), scale[0] * (1.5f));

	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();

}

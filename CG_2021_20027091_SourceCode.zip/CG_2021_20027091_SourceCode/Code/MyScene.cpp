#include "MyScene.h"
#include "Floor.h"
#include "desk.h"
#include "Fridge.h"
#include "BookShelf.h"
#include "LeftWall.h"
#include "BackWall.h"
#include "Fan.h"
#include "Board.h"
#include "Computer.h"
#include "AddBook.h"
#include "Balloon.h"
#include "pool.h"
#include "Seat.h"
#include "RightWall.h"
#include "Window.h"
#include "Water.h"
#include "Wall.h"
/*
* initialise the scene of the project 
* initialise the objects and add to the scene
*/
MyScene::MyScene(int argc, char** argv, const char *title, const int& windowWidth, const int& windowHeight)
	: Scene(argc, argv, title, windowWidth, windowHeight){}

void MyScene::Initialise()
{
	// set the background colour of the scene to black
    
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    
	Floor *f = new Floor("./Textures/floor1.bmp");
	Wall* w = new Wall("./Textures/vx3.bmp","./Textures/door.bmp");
	LeftWall* lf = new LeftWall("./Textures/vx3.bmp","./Textures/window1.bmp");
	RightWall* r = new RightWall("./Textures/vx3.bmp");
	BackWall * bw = new BackWall("./Textures/vx3.bmp");
	Desk* d = new Desk ("./Textures/desk3.bmp", "./Textures/desk2.bmp");
	Fridge* a = new Fridge("./Textures/sidewall.bmp","./Textures/wood1.bmp","./Textures/desk2.bmp");
	BookShelf* b = new BookShelf("./Textures/book3.bmp", "./Textures/book2.bmp");
	Fan* fan = new Fan();
	Board* board = new Board("./Textures/floor.bmp");
	Window* window = new Window("./Textures/window.bmp");
	Computer* computer = new Computer("./Textures/balloon.bmp");
	AddBook* book = new AddBook("./Textures/book6.bmp", "./Textures/book6.bmp");
    Balloon* ball = new Balloon("./Textures/balloon2.bmp");
	Seat* seat = new Seat("./Textures/base.bmp", "./Textures/wood2.bmp");
	Water* water = new Water(20, 20, "./Textures/water.bmp");
	Pool* pool = new Pool("./Textures/desk2.bmp","./Textures/rug.bmp");
    ////Users/kelvin/ComputerGraphics/CG_2021_20027091_PROJECT/CG_2021_20027091_SourceCode
    
	//set the size of each object
	lf->size(100.f);
	b->size(100.f);
	r->size(100.f);
	f->size(100.0f);
	w->size(100.f);
	d->size(100.f);
	a->size(100.f);
	bw->size(100.f);
	fan->size(100.f);
	board->size(100.f);
	window->size(100.f);
	computer->size(100.f);
	book->size(100.f);
	ball->size(100.f);
	seat->size(100.f);
	pool->size(100.f);

	//set the position and size of the water object
	water->position(100.0f, -99.9f, 200.0f);
	water->size(100.f);

	//add the objects to the scene
	AddObjectToScene(f);
	AddObjectToScene(r);
	AddObjectToScene(w);
	AddObjectToScene(lf);
	AddObjectToScene(d);
	AddObjectToScene(a);
	AddObjectToScene(b);
	AddObjectToScene(fan);
	AddObjectToScene(bw);
	AddObjectToScene(board);
	AddObjectToScene(window);
	AddObjectToScene(computer);
	AddObjectToScene(book);
	AddObjectToScene(ball);
	AddObjectToScene(seat);
	AddObjectToScene(water);
	AddObjectToScene(pool);
}

// set the perspective of camera
void MyScene::Projection()
{
    GLdouble aspect = static_cast<GLdouble>(windowWidth) / static_cast<GLdouble>(windowHeight);
    gluPerspective(60.0, aspect, 1.0, 1000.0);
}

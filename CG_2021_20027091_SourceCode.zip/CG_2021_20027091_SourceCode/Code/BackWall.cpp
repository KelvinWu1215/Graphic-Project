#include "BackWall.h"

// bound the texture on the object
BackWall::BackWall(const std::string& filename1) :BackWall() {
	texID = Scene::GetTexture(filename1);

}
void BackWall::Display()
{
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);

	//set the lighting reflection and enable to bind the object with texture
	float lighting1[] = { 0.7f,0.7f,0.7f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

	// draw the back wall
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	//set the normal of this face
	glNormal3f(0.f, 0.f, 1.f);
	//bind with texture
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-2.f), scale[0] * (-1.f), scale[0] * (-2.f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (2.f), scale[0] * (-1.f), scale[0] * (-2.f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (2.f), scale[0] * (3.f), scale[0] * (-2.f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-2.f), scale[0] * (3.f), scale[0] * (-2.f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

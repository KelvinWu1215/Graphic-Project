#include "desk.h"
// bound the textures on the object
Desk::Desk(const std::string& filename1, const std::string& filename2) : Desk() {
	texID = Scene::GetTexture(filename1);
	texID2 = Scene::GetTexture(filename2);
}

void Desk::Display()
{
	// draw a desk in the scene
	DrawDesk();
}

// divide the desk into 3 parts.
void Desk::DrawDesk(){
	DrawTop();
	DrawLeg();
	DrawBox();
}
void Desk::DrawLeg() {
    glPushMatrix();
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glDisable(GL_COLOR_MATERIAL);
    float lighting1[] = { 0.15f,0.15f,0.15f,1.f };
    float lighting2[] = { 0.77f,0.77f,0.77f,1.0f };
    float lighting3[] = { 0.4f,0.4f,0.42f,1.0f };
    float specular[] = { 1.0f,1.0f,1.0f,1.0f };
    float shininess = 100.0f;


    //the first leg.
    // front
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glTranslatef(scale[0] * (2.3f),0, 0);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
    glNormal3f(0.f, 0.f, 1.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-2.0f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-2.0f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.9f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.9f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);
    
    //left
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
    glNormal3f(-1.f, 0.f, 0.f);
    glVertex3f(scale[0] * (-2.f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glVertex3f(scale[0] * (-2.f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glVertex3f(scale[0] * (-2.f), scale[0] * (0.1f), scale[0] * (-2.0f));
    glVertex3f(scale[0] * (-2.f), scale[0] * (-1.f), scale[0] * (-2.0f));
    glEnd();

    //right
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(1.f, 0.f, 0.f);
    glVertex3f(scale[0] * (-1.9f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glVertex3f(scale[0] * (-1.9f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glVertex3f(scale[0] * (-1.9f), scale[0] * (-1.f), scale[0] * (-2.0f));
    glVertex3f(scale[0] * (-1.9f), scale[0] * (0.1f), scale[0] * (-2.0f));
    glEnd();

    //the second leg
    // front
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
    glNormal3f(0.f, 0.f, 1.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.4f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.4f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //right
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting3));
    glNormal3f(1.f, 0.f, 0.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-1.4f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-1.4f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.4f), scale[0] * (-1.f), scale[0] * (-2.0f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.4f), scale[0] * (0.1f), scale[0] * (-2.0f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //left
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting3));
    glNormal3f(-1.f, 0.f,0.f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-1.f), scale[0] * (-2.0f));
    glVertex3f(scale[0] * (-1.5f), scale[0] * (0.1f), scale[0] * (-2.0f));
    glEnd();

    //the third leg
    // front
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
    glNormal3f(0.f, 0.f, 1.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-0.4f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-0.4f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-0.3f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-0.3f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //right
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting3));
    glNormal3f(1.f, 0.f, 0.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-0.3f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-0.3f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-0.3f), scale[0] * (-1.f), scale[0] * (-2.0f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-0.3f), scale[0] * (0.1f), scale[0] * (-2.0f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //left
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting3));
    glNormal3f(-1.f, 0.f, 0.f);
    glVertex3f(scale[0] * (-0.4f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glVertex3f(scale[0] * (-0.4f), scale[0] * (-1.f), scale[0] * (-0.5f));
    glVertex3f(scale[0] * (-0.4f), scale[0] * (-1.f), scale[0] * (-2.0f));
    glVertex3f(scale[0] * (-0.4f), scale[0] * (0.1f), scale[0] * (-2.0f));
    glEnd();



    glEnable(GL_COLOR_MATERIAL);

    glPopAttrib();
    glPopMatrix();
}

void Desk::DrawBox() {

    glPushMatrix();
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glDisable(GL_COLOR_MATERIAL);
    float lighting1[] = { 0.15f,0.15f,0.15f,1.f };
    float lighting2[] = { 0.66f,0.66f,0.66f,1.0f };
    float specular[] = { 1.0f,1.0f,1.0f,1.0f };
    float shininess = 100.0f;

    //the first box
    // front
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glTranslatef(scale[0] * (2.3f),0, 0);

    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
    glNormal3f(0.f, 0.f, 1.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (0.1f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.2f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.2f), scale[0] * (-0.45f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (0.1f), scale[0] * (-0.45f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //bottom
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(0.f, -1.f, 0.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.2f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.2f), scale[0] * (-2.f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.2f), scale[0] * (-2.f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.2f), scale[0] * (-0.45f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //the second box
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
    glNormal3f(0.f, 0.f, 1.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.22f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.52f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.52f), scale[0] * (-0.45f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.22f), scale[0] * (-0.45f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //bottom
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(0.f, -1.f, 0.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.52f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.52f), scale[0] * (-2.f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.52f), scale[0] * (-2.f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.52f), scale[0] * (-0.45f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);



    //the third box
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
    glNormal3f(0.f, 0.f, 1.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.54f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.84f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.84f), scale[0] * (-0.45f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.54f), scale[0] * (-0.45f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //bottom
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(0.f, -1.f, 0.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.84f), scale[0] * (-0.45f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-1.5f), scale[0] * (-0.84f), scale[0] * (-2.f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.84f), scale[0] * (-2.f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-1.89f), scale[0] * (-0.84f), scale[0] * (-0.45f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //draw the sphere.
    glPushMatrix();
    glTranslatef(scale[0] *(-1.7f), scale[0] *(-0.05f), scale[0] *(-0.42f));
    glColor3f(0.f, 0.f, 0.f);
    glutSolidSphere(3, 50, 50);
    glTranslatef(0.f, scale[0] * (-0.32f),0.f);
    glutSolidSphere(3, 50, 50);
    glTranslatef(0.f, scale[0] * (-0.32f), 0.f);
    glutSolidSphere(3, 50, 50);
    glPopMatrix();

    
    glEnable(GL_COLOR_MATERIAL);
    glPopAttrib();
    glPopMatrix();
}
void Desk::DrawTop() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	float lighting1[] = { 0.15f,0.15f,0.15f,1.f };
	float lighting2[] = { 0.77f,0.77f,0.77f,1.0f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

	// top
    glTranslatef(scale[0] * (2.3f),0, 0);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(specular));
	glNormal3f(0.f, -1.f, 0.f);
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.22f), scale[0] * (-.5f));
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.22f), scale[0] * (-2.f));
	glVertex3f(scale[0] * (-2.f), scale[0] * (0.22f), scale[0] * (-2.f));
	glVertex3f(scale[0] * (-2.f), scale[0] * (0.22f), scale[0] * (-.5f));
	glEnd();
	//front

	//bind with the texture
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
	glNormal3f(0.f, 1.f, 0.f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.1f), scale[0] * (-0.5f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.22f), scale[0] * (-0.5f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (0.22f), scale[0] * (-0.5f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (0.1f), scale[0] * (-0.5f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	//right
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	glNormal3f(1.f, 0.f, 0.f);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.22f), scale[0] * (-0.5f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.1f), scale[0] * (-0.5f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.1f), scale[0] * (-2.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.22f), scale[0] * (-2.0f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
    

    
    //right
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting2));
    glNormal3f(1.f, 0.f, 0.f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (-2.f), scale[0] * (0.1f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (-2.f), scale[0] * (0.22f), scale[0] * (-0.5f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-2.f), scale[0] * (0.22f), scale[0] * (-2.0f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-2.f), scale[0] * (0.1f), scale[0] * (-2.0f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);
    
    
    
    
	//bottom
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(0.f, -1.f, 0.f);
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.1f), scale[0] * (-2.f));
	glVertex3f(scale[0] * (-0.3f), scale[0] * (0.1f), scale[0] * (-0.5f));
	glVertex3f(scale[0] * (-2.f), scale[0] * (0.1f), scale[0] * (-0.5f));
	glVertex3f(scale[0] * (-2.f), scale[0] * (0.1f), scale[0] * (-2.f));
	glEnd();

	glEnable(GL_COLOR_MATERIAL);

	glPopAttrib();
	glPopMatrix();
}


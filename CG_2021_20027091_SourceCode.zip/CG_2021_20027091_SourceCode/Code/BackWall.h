#pragma once
#include "DisplayableObject.h"

class BackWall :
	public DisplayableObject
{
public:
	BackWall() {};
	// to get the texture which is bound with the object when the costructor initialise
	BackWall(const std::string& filename1);
	~BackWall() {};

	void Display();
private:
	GLint texID;
};


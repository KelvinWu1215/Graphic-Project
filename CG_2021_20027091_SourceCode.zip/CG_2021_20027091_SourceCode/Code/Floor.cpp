#include "Floor.h"

//get the 
Floor::Floor(const std::string& filename1) :Floor() {
	texID = Scene::GetTexture(filename1);

}

void Floor::Display()
{

	// Draws four walls : top, left , back ,right

	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	//set the lighting color of the floor
	float lighting1[] = { 0.8f,0.8f,0.8f,0.8f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

	// draw the floor

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);

	glBegin(GL_QUADS);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(1.f, 0.f, 0.f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-2.f), scale[0] * (-1.f), scale[0] * (2.f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (2.f), scale[0] * (-1.f), scale[0] * (2.f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (2.f), scale[0] * (-1.f), scale[0] * (-2.f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-2.f), scale[0] * (-1.f), scale[0] * (-2.f));
	glEnd();
	//clear the texture attribute
	glBindTexture(GL_TEXTURE_2D, NULL);

	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

#include "Fridge.h"


Fridge::Fridge(const std::string& filename1, const std::string& filename2, const std::string& filename3) :Fridge() {
	texID = Scene::GetTexture(filename1);
	texID2 = Scene::GetTexture(filename2);
	texID3 = Scene::GetTexture(filename3);

}
void Fridge::Display()
{
	
	DrawFridge();
}
//divide the fridge into 3 parts.
void Fridge::DrawFridge() {

	DrawFrame();
	DrawDoor();
	DrawHandle();
}

void Fridge::DrawFrame() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	//set the color
	float lighting1[] = { 0.85f,0.85f,0.85f,1.0f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	
	//top
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
    glTranslatef(scale[0] * (-2.9f),0, 0);
	glBegin(GL_QUADS);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(0.f, -1.f, 0.f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (0.9f), scale[0] * (2.0f), scale[0] * (-2.f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (2.0f), scale[0] * (2.0f), scale[0] * (-2.f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (2.0f), scale[0] * (2.0f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (0.9f), scale[0] * (2.0f), scale[0] * (-1.0f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	//front
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(0.f, 0.f, 1.f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (0.9f), scale[0] * (2.0f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (0.9f), scale[0] * (-1.0f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.99f), scale[0] * (-1.0f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.99f), scale[0] * (2.0f), scale[0] * (-1.0f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);

	//left
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(-1.f, 0.f, 0.f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (0.9f), scale[0] * (-1.0f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (0.9f), scale[0] * (2.0f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (0.9f), scale[0] * (2.0f), scale[0] * (-2.0f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (0.9f), scale[0] * (-1.0f), scale[0] * (-2.0f));
    
    //right
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);
    glBegin(GL_QUADS);
    //set the lighting reflection
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(-1.f, 0.f, 0.f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (2.f), scale[0] * (2.0f), scale[0] * (-1.0f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (2.f), scale[0] * (-1.0f), scale[0] * (-1.0f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (2.f), scale[0] * (-1.0f), scale[0] * (-2.0f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (2.f), scale[0] * (2.0f), scale[0] * (-2.0f));

	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

void Fridge::DrawDoor() {


	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	float bDiffuse[] = { 0.99f,0.99f,0.98f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(bDiffuse));

	// draw the first door of fridge
	//front
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
    glTranslatef(scale[0] * (-2.9f),0, 0);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (0.8f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.2f), scale[0] * (-0.9f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.2f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (0.8f), scale[0] * (-0.9f));
	glEnd();
	//back
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (0.8f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.2f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.2f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (0.8f), scale[0] * (-1.0f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);


	//right
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.2f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (0.8f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (0.8f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.2f), scale[0] * (-0.9f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	//left
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (0.8f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.2f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.2f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (0.8f), scale[0] * (-0.9f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	//top
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (0.8f), scale[0] * (-.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (0.8f), scale[0] * (-.9f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (0.8f), scale[0] * (-1.f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (0.8f), scale[0] * (-1.f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	//bottom
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.2f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.2f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.2f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.2f), scale[0] * (-0.9f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);


	// draw the second door of fridge
	//front
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.25f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.75f), scale[0] * (-0.9f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.75f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.25f), scale[0] * (-0.9f));
	glEnd();

	//back
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.25f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.75f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.75f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.25f), scale[0] * (-1.0f));
	glEnd();


	//right
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.75f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.25f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.25f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.75f), scale[0] * (-0.9f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	//left
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.25f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.75f), scale[0] * (-1.0f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.75f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.25f), scale[0] * (-0.9f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	//top
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.25f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.25f), scale[0] * (-0.9f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.25f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.25f), scale[0] * (-1.0f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	//bottom
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.75f), scale[0] * (-1.0f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.75f), scale[0] * (-0.9f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.75f), scale[0] * (-0.9f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.85f), scale[0] * (-0.75f), scale[0] * (-1.0f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
    
    
    // draw the third door of fridge
    //front
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.75f), scale[0] * (-0.9f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.25f), scale[0] * (-0.9f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.25f), scale[0] * (-0.9f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.75f), scale[0] * (-0.9f));
    glEnd();

    
    //back
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.25f), scale[0] * (-1.0f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.75f), scale[0] * (-1.0f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.75f), scale[0] * (-1.0f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.25f), scale[0] * (-1.0f));
    glEnd();


    //right
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.25f), scale[0] * (-1.0f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.75f), scale[0] * (-1.0f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.75f), scale[0] * (-0.9f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.25f), scale[0] * (-0.9f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //left
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.25f), scale[0] * (-.9f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.75f), scale[0] * (-.9f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.75f), scale[0] * (-1.f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.25f), scale[0] * (-1.f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //top
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.25f), scale[0] * (-1.0f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.25f), scale[0] * (-0.9f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.25f), scale[0] * (-0.9f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.25f), scale[0] * (-1.0f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

    //bottom
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.75f), scale[0] * (-.9f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (1.75f), scale[0] * (-1.f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.75f), scale[0] * (-1.f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.85f), scale[0] * (1.75f), scale[0] * (-.9f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

void Fridge::DrawHandle() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	float lighting1[] = { 0.15f,0.13f,0.15f,1.0f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glTranslatef(scale[0] * (-2.9f),0, 0);


	glPushMatrix();
	glTranslatef(scale[0] * (1.25f), (scale[0] * -0.35f), (scale[0] * (-0.85f)));
	glScalef(0.5f,0.2f,0.1f);
	glutSolidCube(50);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(scale[0] * (1.25f), (scale[0] * 0.35f), (scale[0] * (-0.85f)));
	glScalef(0.2f, 0.5f, 0.1f);
	glutSolidCube(50);
	glPopMatrix();
    glPushMatrix();
    glTranslatef(scale[0] * (1.25f), (scale[0] * 1.55f), (scale[0] * (-0.85f)));
    glScalef(0.5f,0.2f,0.1f);
    glutSolidCube(50);
    glPopMatrix();
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

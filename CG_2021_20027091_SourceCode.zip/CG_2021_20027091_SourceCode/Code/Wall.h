#include "DisplayableObject.h"

class Wall :
    public DisplayableObject
{
public:
    Wall() {};
    Wall(const std::string& filename1, const std::string& filename2);
    ~Wall() {};

    void Display();
    void DrawKnob();
private:
    GLint texID, texID2;
    float yrot;
};

#pragma once
#include "DisplayableObject.h"

class RightWall :
	public DisplayableObject
{
public:
	RightWall() {};
	RightWall(const std::string& filename1);
	~RightWall() {};

	void Display();
private:
	GLint texID;
};


#pragma once

#include "Scene.h"

class MyScene :
	public Scene
{
public:
	MyScene(int argc, char** argv, const char *title, const int& windowWidth, const int& windowHeight);
	~MyScene() {};

private:

	//initialise the scene and objects
	void Initialise();
	// set the projection of the scene
	void Projection();

};

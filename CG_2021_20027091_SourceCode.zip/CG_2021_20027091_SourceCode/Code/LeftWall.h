#pragma once
#include "DisplayableObject.h"

class LeftWall :
	public DisplayableObject
{
public:
	LeftWall() {};
	LeftWall(const std::string& filename1, const std::string& filename2);
	~LeftWall() {};

	void Display();
	void DrawWall();
	void DrawBG();

private:
	GLint texID;
	GLint texID2;
};


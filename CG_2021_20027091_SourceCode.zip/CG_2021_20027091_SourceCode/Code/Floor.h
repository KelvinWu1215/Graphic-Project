#pragma once
#include "DisplayableObject.h"

class Floor:
	public DisplayableObject
{
public:
	Floor() {};
	Floor(const std::string& filename1);
	~Floor() {};

	void Display();
private:
	GLint texID;
};


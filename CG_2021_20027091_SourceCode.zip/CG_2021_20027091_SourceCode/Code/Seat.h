#pragma once
#include "DisplayableObject.h"

class Seat :
    public DisplayableObject
{
public:
    Seat() {};
    Seat(const std::string& filename1, const std::string& filename2);
    ~Seat() {};

    void Display();
    void DrawBase();
    void DrawLegs();
    void DrawLeg();
private:
    GLint texID;
    GLint texID2;
};


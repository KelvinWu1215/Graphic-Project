
#pragma once
#include "DisplayableObject.h"

class Pool :
	public DisplayableObject
{
public:
	Pool() {};
	Pool(const std::string& filename1, const std::string& filename2);
	~Pool() {};

	void Display();
	void DrawPool();

private:
	GLint texID, texID2;
};


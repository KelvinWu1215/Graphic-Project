#pragma once
#include "DisplayableObject.h"

class AddBook :
	public DisplayableObject
{
public:
	AddBook() {};
	// to get the texture which is bound with the object when the costructor initialise
	AddBook(const std::string& filename1, const std::string&filename2);
	~AddBook() {};

	void Display();
	void DrawBook();
	void DrawBook2();
private:
	GLint texID;
	GLint texID2;
};


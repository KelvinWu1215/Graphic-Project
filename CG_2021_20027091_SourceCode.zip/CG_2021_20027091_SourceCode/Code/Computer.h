#pragma once

#include "DisplayableObject.h"
#include "Animation.h"
class Computer :
	public DisplayableObject,
    public Animation
{
public:
	Computer() {};
	//get one texture to bind the computer which represent the screen
	Computer(const std::string& filename1);
	~Computer() {};

	void Display();
	void DrawComputer();

    void Update(const double& deltaTime);
private:
	GLint texID;

    float yrot = 0;
    float moveX = 0;
    float moveY = 0;
    float moveZ = 0;
    int state = 1;
};


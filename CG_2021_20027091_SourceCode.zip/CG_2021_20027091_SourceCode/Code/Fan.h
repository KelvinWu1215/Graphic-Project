#pragma once
#include "DisplayableObject.h"
#include "Animation.h"

//in this class, I set the animation of the fan, and change the speed of the rotation
class Fan :
	public DisplayableObject,
	public Animation
{
public:
	Fan() {};
	~Fan() {};

	void Display();
	void DrawFan();
	void DrawBase();
	void DrawBlades();
	void Material_Fan();
	void Update(const double& deltaTime);
	//set the privete variables to simulate rotating
private:
	float yrot=0;
	float count = 0;

};


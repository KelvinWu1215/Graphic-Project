#include "Board.h"

// bound the texture on the object
Board::Board(const std::string& filename1) :Board() {
	texID = Scene::GetTexture(filename1);

}

void Board::Display() {

	DrawBoard();
}

void Board::DrawBoard() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	float lighting1[] = { 0.9f,0.9f,0.9f,1.0f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

	//draw the board which is located on the right wall
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(1.f, 0.f, 0.f);
	//back
    
	glVertex3f(scale[0]*(2.f), scale[0] * (1.0f), scale[0] * (-1.5f));
	glVertex3f(scale[0] * (2.f), scale[0] * (1.9f), scale[0] * (-1.5f));
	glVertex3f(scale[0] * (2.f), scale[0] * (1.9f), scale[0] * (-1.0f));
	glVertex3f(scale[0] * (2.f), scale[0] * (1.0f), scale[0] * (-1.0f));

	//front
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.0f), scale[0] * (-1.f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.9f), scale[0] * (-1.f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.9f), scale[0] * (-1.5f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.0f), scale[0] * (-1.5f));
	
	//right
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.0f), scale[0] * (-1.f));
	glVertex3f(scale[0] * (2.0f), scale[0] * (1.0f), scale[0] * (-1.f));
	glVertex3f(scale[0] * (2.0f), scale[0] * (1.9f), scale[0] * (-1.5f));
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.9f), scale[0] * (-1.5f));

	//left
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.0f), scale[0] * (-1.0f));
	glVertex3f(scale[0] * (2.0f), scale[0] * (1.0f), scale[0] * (-1.0f));
	glVertex3f(scale[0] * (2.0f), scale[0] * (1.9f), scale[0] * (-1.0f));
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.9f), scale[0] * (-1.0f));

	//top
	glVertex3f(scale[0] * (2.0f), scale[0] * (1.9f), scale[0] * (-1.5f));
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.9f), scale[0] * (-1.5f));
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.9f), scale[0] * (-1.0f));
	glVertex3f(scale[0] * (2.0f), scale[0] * (1.9f), scale[0] * (-1.0f));

	//bottom
	glVertex3f(scale[0] * (2.0f), scale[0] * (1.0f), scale[0] * (-1.0f));
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.0f), scale[0] * (-1.0f));
	glVertex3f(scale[0] * (1.97f), scale[0] * (1.0f), scale[0] * (-1.5f));
	glVertex3f(scale[0] * (2.0f), scale[0] * (1.0f), scale[0] * (-1.5f));

	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();

}

#include "Computer.h"

// bound the texture on the object
Computer::Computer(const std::string& filename1) :Computer() {
	texID = Scene::GetTexture(filename1);

}
//show the object
void Computer::Display() {
	DrawComputer();
}
//draw the computer
void Computer::DrawComputer() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);

	float lighting1[] = { 0.55f,0.55f,0.55f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	//set the lighting reflection
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    
    
    glPushMatrix();
    // draw a object besides the computer
    glTranslatef(scale[0] * (1.75f), scale[0] * (0.37f), scale[0] * (-1.5f));
    glRotatef(yrot, 0, 1 ,0 );
    glScalef(20, 20, 20);
    glutWireIcosahedron();
    glPopMatrix();
    
	//draw base
	glPushMatrix();
	glTranslatef(scale[0]*(1.0f),scale[0]*( 0.25f), scale[0]*(-1.5f));
	glScalef(10.f,0.8f,6.f);
	glutSolidCube(scale[0]*(0.1));
	glPopMatrix();

	//draw the screen
	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
    glTranslatef(scale[0] * (2.f),0, 0);
	glBegin(GL_QUADS);
	
	//front
	//bind with textures 
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.29f), scale[0] * (-1.8f));//left down
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.29f), scale[0] * (-1.8f));//right down
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.85f), scale[0] * (-1.8f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.85f), scale[0] * (-1.8f));

	//back
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.29f), scale[0] * (-1.84f));//left down
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.29f), scale[0] * (-1.84f));//right down
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.85f), scale[0] * (-1.84f));
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.85f), scale[0] * (-1.84f));

	//top
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.85f), scale[0] * (-1.8f));
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.85f), scale[0] * (-1.8f));
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.85f), scale[0] * (-1.84f));
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.85f), scale[0] * (-1.84f));

	//bottom
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.29f), scale[0] * (-1.8f));
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.29f), scale[0] * (-1.8f));
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.29f), scale[0] * (-1.84f));
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.29f), scale[0] * (-1.84f));
	
	//right
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.85f), scale[0] * (-1.84f));
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.85f), scale[0] * (-1.8f));
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.29f), scale[0] * (-1.8f));
	glVertex3f(scale[0] * (-0.5f), scale[0] * (0.29f), scale[0] * (-1.84f));

	//left
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.85f), scale[0] * (-1.84f));
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.85f), scale[0] * (-1.8f));
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.29f), scale[0] * (-1.8f));
	glVertex3f(scale[0] * (-1.5f), scale[0] * (0.29f), scale[0] * (-1.84f));
	glEnd();


	// clear the texture
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopMatrix();
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

void Computer::Update(const double& deltaTime) {

    // set the rotating speed based on the deltaTime.

    yrot += 100.0f * static_cast<float>(deltaTime);

}

#include "Seat.h"
//get the textures in the constructor

Seat::Seat(const std::string& filename1, const std::string& filename2) :Seat() {
	texID = Scene::GetTexture(filename1);
	texID2 = Scene::GetTexture(filename2);
}
//show the seat in the scene
void Seat::Display() {
	glPushMatrix();
	//change the original position.
	glTranslatef(0, 0, 15.f);
	DrawBase();
	DrawLegs();
	glPopMatrix();
}

void Seat::DrawBase() {

	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	float lighting1[] = { 0.85f,0.85f,0.85f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	//set the light attributes
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	//draw base

	//top
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.35f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.35f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.35f), scale[0] * (-0.60f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.35f), scale[0] * (-0.60f));

	// bottom
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.42f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.42f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.42f), scale[0] * (-0.60f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.42f), scale[0] * (-0.60f));

	//left
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.35f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.42f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.42f), scale[0] * (-0.60f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.35f), scale[0] * (-0.60f));

	//right
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.42f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.35f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.35f), scale[0] * (-0.60f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.42f), scale[0] * (-0.60f));

	//back
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.35f), scale[0] * (-0.60f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.42f), scale[0] * (-0.60f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.42f), scale[0] * (-0.60f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.35f), scale[0] * (-0.60f));

	//front
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.42f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (1.65f), scale[0] * (-0.35f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.35f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (1.05f), scale[0] * (-0.42f), scale[0] * (0.05f));
    
    //back of seat (face to computer)
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.65f), scale[0] * (0.5f), scale[0] * (0.05f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.65f), scale[0] * (-0.35f), scale[0] * (0.05f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (-0.35f), scale[0] * (0.05f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (0.5f), scale[0] * (0.05f));
    
    //back of seat (face to user)
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (1.65f), scale[0] * (-0.35f), scale[0] * (0.05f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (1.65f), scale[0] * (.5f), scale[0] * (0.05f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (.5f), scale[0] * (0.05f));
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (1.05f), scale[0] * (-0.35f), scale[0] * (0.05f));
	
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();

}

void Seat::DrawLegs() {
	//draw four legs
	glPushMatrix();
    glTranslatef(220, 0, 0);
	DrawLeg();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(275, 0, 0);
	DrawLeg();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(275, 0, -55);
	DrawLeg();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(220, 0, -55);
	DrawLeg();
	glPopMatrix();
}

void Seat::DrawLeg() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	float lighting1[] = { 0.85f,0.85f,0.85f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));


	//fornt
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-1.15f), scale[0] * (-0.40f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-1.15f), scale[0] * (-1.f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-1.10f), scale[0] * (-1.f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-1.10f), scale[0] * (-0.40f), scale[0] * (0.05f));
	//back
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-1.15f), scale[0] * (-0.40f), scale[0] * (0.00f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-1.15f), scale[0] * (-1.f), scale[0] * (0.00f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-1.10f), scale[0] * (-1.f), scale[0] * (0.00f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-1.10f), scale[0] * (-0.40f), scale[0] * (0.00f));

	//left 
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-1.15f), scale[0] * (-0.40f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-1.15f), scale[0] * (-1.f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-1.15f), scale[0] * (-1.f), scale[0] * (0.00f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-1.15f), scale[0] * (-0.40f), scale[0] * (0.00f));

	//right
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-1.10f), scale[0] * (-0.40f), scale[0] * (0.05f));
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-1.10f), scale[0] * (-1.f), scale[0] * (0.05f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-1.10f), scale[0] * (-1.f), scale[0] * (0.00f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-1.10f), scale[0] * (-0.40f), scale[0] * (0.00f));

	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

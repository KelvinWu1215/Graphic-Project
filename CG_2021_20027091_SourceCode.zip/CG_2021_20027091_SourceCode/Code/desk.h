
#pragma once
#include "DisplayableObject.h"

class Desk :
	public DisplayableObject
{
public:
	Desk() {};
	Desk(const std::string& filename1, const std::string& filename2);
	~Desk() {};

	void Display();
	void DrawDesk();
	void DrawTop();
	void DrawLeg();
	void DrawBox();
private:
	GLint texID;
	GLint texID2;
};


#include "LeftWall.h"

//get two textures in this constructor
LeftWall::LeftWall(const std::string& filename1, const std::string& filename2) :LeftWall() {
	texID = Scene::GetTexture(filename1);
	texID2 = Scene::GetTexture(filename2);
}

void LeftWall::Display()
{
	//set the background outsides the room
	DrawBG();
	DrawWall();

}

void LeftWall::DrawBG() {
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);
	//set the color when lighting 
	float lighting1[] = { 0.8f,0.8f,0.8f,0.8f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

	// draw the left background
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID2);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(1.f, 0.f, 0.f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-4.0f), scale[0] * (-2.f), scale[0] * (3.f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-4.0f), scale[0] * (-2.f), scale[0] * (-3.f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-4.0f), scale[0] * (4.f), scale[0] * (-3.f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-4.00f), scale[0] * (4.f), scale[0] * (3.f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
    
    //draw the right background
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(1.f, 0.f, 0.f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (4.f), scale[0] * (3.f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (4.f), scale[0] * (-3.f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (-2.f), scale[0] * (-3.f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (4.00f), scale[0] * (-2.f), scale[0] * (3.f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);
    
    //draw the back background
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(1.f, 0.f, 0.f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (-2.f), scale[0] * (-3.f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (4.f), scale[0] * (-3.f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-4.0f), scale[0] * (4.f), scale[0] * (-3.f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-4.00f), scale[0] * (-2.f), scale[0] * (-3.f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);
    
    //draw the down background
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(1.f, 0.f, 0.f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (-2.f), scale[0] * (3.f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (-2.f), scale[0] * (-3.f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-4.0f), scale[0] * (-2.f), scale[0] * (-3.f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-4.00f), scale[0] * (-2.f), scale[0] * (3.f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);
    
    //draw the top background
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(1.f, 0.f, 0.f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (4.f), scale[0] * (-3.f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (4.f), scale[0] * (3.f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-4.0f), scale[0] * (4.f), scale[0] * (3.f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-4.00f), scale[0] * (4.f), scale[0] * (-3.f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);
    
    //draw the back background
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID2);
    glBegin(GL_QUADS);
    glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
    glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
    glNormal3f(1.f, 0.f, 0.f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (4.f), scale[0] * (3.f));
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(scale[0] * (4.0f), scale[0] * (-2.f), scale[0] * (3.f));
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(scale[0] * (-4.0f), scale[0] * (-2.f), scale[0] * (3.f));
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(scale[0] * (-4.00f), scale[0] * (4.f), scale[0] * (3.f));
    glEnd();
    glBindTexture(GL_TEXTURE_2D, NULL);

	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
	glPopMatrix();
}

void LeftWall::DrawWall() {

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);

	float lighting1[] = { 0.8f,0.8f,0.8f,1.0f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;

    // draw the left wall
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(1.f, 0.f, 0.f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (-1.f), scale[0] * (-0.5f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (-1.f), scale[0] * (-2.f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (3.f), scale[0] * (-2.f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (3.f), scale[0] * (-0.5f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);


	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(1.f, 0.f, 0.f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (-1.f), scale[0] * (2.f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (-1.f), scale[0] * (0.5f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (3.f), scale[0] * (0.5f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (3.f), scale[0] * (2.f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(1.f, 0.f, 0.f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (1.5f), scale[0] * (0.5f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (1.5f), scale[0] * (-0.5f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (3.f), scale[0] * (-0.5f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (3.f), scale[0] * (0.5f));
	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID);
	glBegin(GL_QUADS);
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glNormal3f(1.f, 0.f, 0.f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (-1.f), scale[0] * (0.5f));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (-1.f), scale[0] * (-0.5f));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (0.5f), scale[0] * (-0.5f));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(scale[0] * (-2.0f), scale[0] * (0.5f), scale[0] * (0.5f));
	glEnd();

	glBindTexture(GL_TEXTURE_2D, NULL);
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
}

#include "Balloon.h"

// bound the texture on the object
Balloon::Balloon(const std::string& filename1) {
	texID = Scene::GetTexture(filename1);
}
// show the object 
void Balloon::Display() {

	DrawBalloon();
}

//draw the balloon
void Balloon::DrawBalloon() {

	//create a obj in the scene to draw a sphere which can bound with the texture

	GLUquadricObj* qobj = gluNewQuadric();
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_COLOR_MATERIAL);

	//set the lighting reflection

	float lighting1[] = { 0.85f,0.85f,0.85f,1.f };
	float specular[] = { 1.0f,1.0f,1.0f,1.0f };
	float shininess = 100.0f;
	//set the lighting attributes of the ball
	glMaterialfv(GL_FRONT, GL_SPECULAR, static_cast<GLfloat*>(specular));
	glMaterialf(GL_FRONT, GL_SHININESS, static_cast<GLfloat>(shininess));
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, static_cast<GLfloat*>(lighting1));
	glEnable(GL_TEXTURE_2D);

	//bind the texture with the obj
    
    gluQuadricTexture(qobj, GLU_TRUE);
	glBindTexture(GL_TEXTURE_2D, texID);
	glPushMatrix();

	//set the animation movement of the sphere

	glTranslatef(scale[0] * -1.f-moveX, scale[0] * 0.3f - moveY, scale[0] * 1.8f - moveZ);
    
	glRotatef(yrot, 0, 1 ,0 );
    glRotatef(270, 1, 0, 0);
	//draw the sphere

	gluSphere(qobj, 25.0, 80,80);
    
	glPopMatrix();
    
    //Draw the line under the balloon
	glBindTexture(GL_TEXTURE_2D, NULL);
    glTranslatef(scale[0] * -1.f-moveX, scale[0] * 0.0f - moveY, scale[0] * 1.8f - moveZ);
    glScalef(0.1f,2.f,0.1f);
    glutSolidCube(20);
    
    
	glEnable(GL_COLOR_MATERIAL);
	glPopAttrib();
    glPopMatrix();
    
}

/*
*Set the motion state of the balloon: state1 represents rolling to the left, down and near to us, and state2 represents rolling to the right, up and go far away.
*/
void Balloon::Update(const double& deltaTime) {

	// set the rotating speed based on the deltaTime.

	yrot += 100.0f * static_cast<float>(deltaTime);
	switch (state) {
	case 1:
		if (moveZ < 350) {
			moveZ += 130.0f * static_cast<float>(deltaTime);
            moveX -= 90.0f * static_cast<float>(deltaTime);
            moveY -= 80.0f * static_cast<float>(deltaTime);
            glRotatef(yrot, 0, 1 ,0 );
		}
		else
			state = 2; //the moveZ, X, Y have to be the same, otherwise the object will move the origenal position
		break;
	case 2:
		if (moveZ > 0) {
			moveZ -= 130.0f * static_cast<float>(deltaTime);
            moveX += 90.0f * static_cast<float>(deltaTime);
            moveY += 80.0f * static_cast<float>(deltaTime);
            glRotatef(yrot, 0, -1 ,0 );
		}
		else
			state = 1;
		break;
	}
	

}
